package com.register.registerStudents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterStudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterStudentsApplication.class, args);
	}

}
