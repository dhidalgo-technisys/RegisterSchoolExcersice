package com.register.registerStudents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
